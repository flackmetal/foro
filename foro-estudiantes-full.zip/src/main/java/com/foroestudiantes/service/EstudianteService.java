package com.foroestudiantes.service;

import com.foroestudiantes.model.Estudiante;
import com.foroestudiantes.repository.EstudianteRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EstudianteService {
    private final EstudianteRepository repo;

    public EstudianteService(EstudianteRepository repo) {
        this.repo = repo;
    }

    public Estudiante crear(Estudiante e) {
        return repo.save(e);
    }

    public List<Estudiante> listar() {
        return repo.findAll();
    }

    public Estudiante buscar(Long id) {
        return repo.findById(id).orElse(null);
    }
}
