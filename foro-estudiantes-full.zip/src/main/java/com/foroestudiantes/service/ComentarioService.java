package com.foroestudiantes.service;

import com.foroestudiantes.model.Comentario;
import com.foroestudiantes.model.Post;
import com.foroestudiantes.model.Estudiante;
import com.foroestudiantes.repository.ComentarioRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ComentarioService {
    private final ComentarioRepository repo;

    public ComentarioService(ComentarioRepository repo) {
        this.repo = repo;
    }

    public Comentario crear(String texto, Post post, Estudiante autor) {
        Comentario c = Comentario.builder()
                .texto(texto)
                .post(post)
                .autor(autor)
                .creadoEn(LocalDateTime.now())
                .build();
        return repo.save(c);
    }

    public List<Comentario> listarPorPost(Long postId) {
        return repo.findByPostId(postId);
    }
}
