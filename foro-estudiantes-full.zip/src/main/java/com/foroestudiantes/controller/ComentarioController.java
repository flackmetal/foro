package com.foroestudiantes.controller;

import com.foroestudiantes.dto.ComentarioDTO;
import com.foroestudiantes.model.Comentario;
import com.foroestudiantes.model.Estudiante;
import com.foroestudiantes.model.Post;
import com.foroestudiantes.service.ComentarioService;
import com.foroestudiantes.service.EstudianteService;
import com.foroestudiantes.service.PostService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/posts/{postId}/comentarios")
public class ComentarioController {
    private final ComentarioService comentarioService;
    private final PostService postService;
    private final EstudianteService estudianteService;

    public ComentarioController(ComentarioService comentarioService, PostService postService, EstudianteService estudianteService) {
        this.comentarioService = comentarioService;
        this.postService = postService;
        this.estudianteService = estudianteService;
    }

    @PostMapping
    public ResponseEntity<?> crear(@PathVariable Long postId, @Valid @RequestBody ComentarioDTO dto) {
        Post post = postService.buscar(postId);
        if (post == null) return ResponseEntity.badRequest().body("Post no encontrado");
        Estudiante autor = estudianteService.buscar(dto.getEstudianteId());
        if (autor == null) return ResponseEntity.badRequest().body("Estudiante no encontrado");

        Comentario c = comentarioService.crear(dto.getTexto(), post, autor);
        return ResponseEntity.ok(c);
    }

    @GetMapping
    public ResponseEntity<List<Comentario>> listar(@PathVariable Long postId) {
        return ResponseEntity.ok(comentarioService.listarPorPost(postId));
    }
}
