package com.foroestudiantes.controller;

import com.foroestudiantes.dto.PostDTO;
import com.foroestudiantes.model.Estudiante;
import com.foroestudiantes.model.Post;
import com.foroestudiantes.service.EstudianteService;
import com.foroestudiantes.service.PostService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/posts")
public class PostController {
    private final PostService postService;
    private final EstudianteService estudianteService;

    public PostController(PostService postService, EstudianteService estudianteService) {
        this.postService = postService;
        this.estudianteService = estudianteService;
    }

    @PostMapping
    public ResponseEntity<?> crear(@Valid @RequestBody PostDTO dto) {
        Estudiante autor = estudianteService.buscar(dto.getEstudianteId());
        if (autor == null) return ResponseEntity.badRequest().body("Estudiante no encontrado");

        Post p = Post.builder().titulo(dto.getTitulo()).contenido(dto.getContenido()).build();
        Post creado = postService.crear(p, autor);
        return ResponseEntity.ok(creado);
    }

    @GetMapping
    public ResponseEntity<List<Post>> listar() {
        return ResponseEntity.ok(postService.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtener(@PathVariable Long id) {
        Post p = postService.buscar(id);
        if (p == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(p);
    }
}
