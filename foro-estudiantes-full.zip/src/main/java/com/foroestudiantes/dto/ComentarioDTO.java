package com.foroestudiantes.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ComentarioDTO {
    @NotBlank
    private String texto;

    @NotNull
    private Long estudianteId;
}
